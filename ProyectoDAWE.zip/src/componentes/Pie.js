// src/componentes/Pie.js
import React from 'react';

const Pie = () => {
  return (
    <footer className="bg-secondary text-white text-center py-2 fixed-bottom rounded-top">
      <p className="mb-0">&copy; 2025 Tienda DAWE</p>
    </footer>
  );
};

export default Pie;
